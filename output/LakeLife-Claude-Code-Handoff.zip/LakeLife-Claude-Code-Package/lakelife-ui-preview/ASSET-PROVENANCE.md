# Asset provenance

## Original brand assets

The following files are byte-for-byte copies of the original assets already preserved in `../lakelife-product-handbook/assets/`. They retain the LakeLife mark, logo, wave motifs, service illustration language and original fonts. No mark was redrawn.

| File | SHA-256 |
| --- | --- |
| `boat.svg` | `5a0622b2eba512a98632add53389ac043142a2fb745ea15168f6cab951cc261b` |
| `bricolage-grotesque-latin.woff2` | `4fd48b2c1ab27220e71f15f990550261b35245c3bdfd8d8025b4bdac0459ee2d` |
| `clean.svg` | `aec019c26e55d35d7a4941cc36fc7f58e9f20613844b694b3f2480fe8ecb7a50` |
| `house.svg` | `b9e05468a0e586916c1158c29a36116e17e051fa6c29cf106d1d4ac7c50cfffc` |
| `lakelife-logo-on-ink.svg` | `64d59027a6c28de19de2702481e41fdf5ef09b8d7c9bda0b9f2305c7a33ccdcf` |
| `lakelife-logo.svg` | `db13dd225332b4cd4c4059afd18ff08cfd7eaf340f57b92246982edcf9d96650` |
| `lakelife-mark.svg` | `d4e4c41a29651309628a7a1ef72f5ec7193f5f95a4362173e074d01139a3146a` |
| `lakelife-wave-divider.svg` | `eb21ae0e70ca06824db651ca02246281b6bae3cda5de1bac77313fc411e6e762` |
| `lakelife-waves.svg` | `468f270688091f13850540f39e272d12f148c86c32ef5cc11261da9d3f1aa9e3` |
| `lift.svg` | `45f859caf7bd5e036fdcb4b411000e391255729a330be4a8fb9a657e7b4a3df5` |
| `manrope-latin.woff2` | `e310b55a7fd9677f5e3555e6c6c4d064fa1f1d24393f0ddbe217cea12a8c432f` |
| `mow.svg` | `c5340618274f60cb018a30084a46b0a00cac06bc0ff134cae0c0e057a01e6093` |
| `pier.svg` | `79fa30557698b1d92d8a45638618093f1aa45594772aa2c71d2e8b3b99d85673` |
| `snow.svg` | `882e2c5451ea49a73a45938b092559007da713b562711ad07f84dcca234e46a3` |
| `toys.svg` | `0e0e808bbb215aedc81bd0fe64f180d74fd8c6fcdd19054c1f32a8b1af12dfb5` |

## Renter audience illustration — 18 October 2026

Added `dist/assets/renter.svg`, then revised it after the owner clarified that the audience is mobile-home/RV park residents. The current icon is a long, low teal park-home/RV with windows, a gold door, entrance steps, wheels and the existing LakeLife wave language. The earlier pitched-roof home and key were removed. This is a new code-native SVG illustration extending the established icon family, not a replacement for the LakeLife master logo. It replaces the cleaning illustration only where that illustration represented the renter audience, and is also used on the renter welcome panel. The original `clean.svg` still represents housekeeping. All original artwork remains unchanged. `renter-icon-preview.png` is a raster rendering of this SVG for easy review; no image-generation model was used for this vector icon.

### Separate mobile-home illustration — 18 October 2026

The owner approved the preceding illustration for RVs and requested an additional mobile-home version. Added `dist/assets/mobile-home.svg`: a long, low teal mobile home with a shallow roof, windows, a gold door, skirting, a small porch and steps, and the LakeLife wave. It has no wheels or trailer hitch. This is another code-native SVG in the same illustration family, with a raster review rendering at `mobile-home-icon-preview.png`.

The approved RV artwork remains unchanged at `dist/assets/renter.svg` and is also supplied at `dist/assets/rv.svg` for clear naming. The artwork refresh now uses the two approved illustrations together for general park/renter placements; each individual SVG remains unchanged. This does not change resident classification or account behavior.

## New illustrative scene

Saved at `dist/assets/lake-morning.png`. Generated with the built-in image generation tool on 17 October 2026. It represents no specific real lake, property, customer or completed service. The UI labels it as illustrative. It must never be used as job completion evidence or a customer testimonial.

### Original scene prompt

Use case: photorealistic-natural. Asset type: wide lifestyle photograph for a LakeLife local website design preview. Create a beautifully natural editorial landscape of a quiet modest Midwestern lakefront on an early autumn morning, Indiana-like flat wooded shoreline, a simple timber dock extending from the lower right into blue-green calm water, warm sunlight through leafy trees at the right, a small tasteful light lake cottage partly visible far right, subtle reeds at the edge. Water fills the center and left with ample open space. Premium but attainable, intimate local lake life, no mountains, no luxury resort, no people, no text, no logos, no UI, no watermarks. Soft warm gold light, deep teal water and subtle mist, realistic imperfect wood and trees, photographic detail, wide 16:9 composition. It is an illustrative scene, not any specific real lake or property.

### Simpler image revision — 17 October 2026

The owner requested a less polished, less visibly AI-styled scene that better fits LakeLife's simple brand. This intermediate version replaced the golden-hour scene with neutral daylight, a weathered dock and an informal shoreline. It was subsequently superseded by the seasonal-pier revision below. Edited with the built-in image-generation tool, using the original generated scene as the edit target.

Exact edit prompt:

Use case: style-transfer. Asset type: LakeLife website hero image. Edit target: the attached lakefront scene. Keep the wide framing, open water on the left, a simple dock extending from the lower right, and a flat wooded Midwestern shoreline. Make it look like an ordinary, unstyled photograph someone took at their Indiana lake cottage on a quiet overcast morning. Replace the dramatic golden sunrise and mist with soft neutral daylight and a pale cloudy sky. Use subdued, true-to-life greens, gray-blue water and weathered gray dock boards. The dock should be practical and a little worn: irregular wood grain, small stains, a few fallen leaves, ordinary visible fasteners, believable construction. Keep the shore informal, with patchy grass and a few weeds; simplify the ornamental-looking vegetation. A plain modest cottage may remain partly visible at the far right. Natural small ripples, no perfectly mirrored reflections. Everyday camera realism, gentle contrast, slightly imperfect detail. Simple, familiar and lived-in. Avoid cinematic lighting, sunbursts, glossy surfaces, HDR, oversharpening, rich gold color grading, landscaping-magazine polish, decorative props, people, text or logos. Preserve usable dark-overlay space for website copy on the left. This remains an illustrative scene, not a specific real property.

### Current revision — seasonal aluminum pier and warm sun

The owner clarified that the scene should show a pier LakeLife would seasonally service, and preferred the sun and enhancement of the first image. The current `dist/assets/lake-morning.png` therefore shows a removable sectional aluminum pier with panel joints and adjustable tubular legs, and restores the original scene's warm sunlight and blue-green water. Edited with the built-in image-generation tool using the first sunny image as the edit target and the simpler scene as a secondary reference. It remains illustrative, not a real customer property or completed job.

Exact edit prompt:

Use case: precise-object-edit. Asset type: LakeLife website hero. Image 1 is the edit target and preferred lighting reference: the original warm sunny lake scene. Image 2 is only a supporting reference for an ordinary, unstyled shoreline. Replace the entire heavy, fixed wooden pier in Image 1 with a believable seasonal sectional aluminum pier of the type a small Indiana lake-service crew installs in spring and removes in fall. Show a narrow walkway made of several clearly separate rectangular 4-by-8-foot modules with silver aluminum perimeter frames, pale gray removable decking panels, visible panel joints and slim adjustable galvanized tubular support legs extending into shallow water at the module connections. The structure rests on support feet, not permanent pilings. Use a small practical rectangular end platform, no elaborate railings. No timber posts, heavy wood beams, fixed wood decking, concrete, marina or luxury floating dock. The pier should be well-used and functional: light scuffs, modest weathering, a couple of ordinary rubber side bumpers, accurate construction and perspective, no impossible joints or duplicate legs. Keep its position extending from lower right toward the lake, with open water on the left for hero text. Restore and preserve the warm sun through the right-side trees, attractive blue-green lake water, gentle warm highlights and lightly enhanced color of Image 1. Keep real texture and soft highlights, not glossy HDR or a showroom finish. Preserve the simple modest cottage, flat Midwestern shoreline, informal vegetation and wide landscape composition. No people, logos, text, service crew, added props or boats. Illustrative scene only, not a specific real property.

## Approved-artwork rollout — 18 October 2026

`park-homes.svg` places the exact approved mobile-home and RV geometry side by side. Neither approved individual file was redrawn. This composite is used for general park-owner/renter communication, without assuming which housing type belongs to a specific account. `house.svg` continues to represent lake homeowners and home-care service; `clean.svg` remains housekeeping.

The same SVGs and proportional PNG exports are supplied in the brand guide and product-handbook asset folders, with the approved aluminum-pier scene. The brand and product guides include an artwork-use appendix; the six launch documents use the combined audience artwork on their covers. Four park/resident social graphics and the opening pitch slide use the approved pair. Existing factual copy and pricing/permission/payment boundaries remain intact.

Native SVG and document-layout tools produced these exports. No new image-generation prompt or new generated scene was used for this rollout.

## Review images

`approved-artwork.png`, `renter-icon-preview.png` and `mobile-home-icon-preview.png` are current native asset renderings. Earlier UI screenshots used superseded artwork and have been removed from the active handoff; local Git history retains them. They were not replaced with new browser captures because the browser tool cannot access the preview's file URL. The HTML and `dist/` contain the current approved images.
